package br.edu.unifae.view;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

public class FrmPedagio extends JInternalFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel painelCadastro;
	private JTextField txtValorDoPedagio;
	private JTextField txtPraca;
	private UtilDateModel model;
	private JDatePanelImpl datePanel;
	private JDatePickerImpl datePicker;

	
	public FrmPedagio() {
		super("Cadastro Pedagio", false, true, false, false);

		// Aqui sera dado o tamanho do formulario.
		int inset = 50;

		setDefaultCloseOperation(FrmMenuPrincipal.DISPOSE_ON_CLOSE);

		// Aqui esta o tutorial para utilizar o JInternalFrame -
		// https://luizgustavoss.wordpress.com/2008/11/07/exemplo-de-jinternalframe/
		@SuppressWarnings("unused")
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(inset, inset, 728, 488);
		
		painelCadastro = new JPanel();
		painelCadastro.setBounds(10, 11, 414, 248);
		getContentPane().add(painelCadastro);
		
	
		JLabel lblValor = new JLabel("Valor");
		lblValor.setBounds(15, 48, 24, 14);
		
		JLabel lblPraa = new JLabel("Pra\u00E7a");
		lblPraa.setBounds(15, 85, 27, 14);
		
		JLabel lblData = new JLabel("Data");
		lblData.setBounds(15, 120, 23, 14);
		
		txtValorDoPedagio = new JTextField();
		txtValorDoPedagio.setBounds(57, 45, 86, 20);
		txtValorDoPedagio.setColumns(10);
		
		txtPraca = new JTextField();
		txtPraca.setBounds(60, 82, 86, 20);
		txtPraca.setColumns(10);
		
		JButton btnNovo = new JButton("Novo");
		btnNovo.setBounds(71, 222, 57, 23);
		btnNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.setBounds(146, 222, 61, 23);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(225, 222, 75, 23);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(318, 222, 63, 23);
		painelCadastro.setLayout(null);
		painelCadastro.setLayout(null);
		painelCadastro.add(lblValor);
		painelCadastro.add(txtValorDoPedagio);
		painelCadastro.add(lblPraa);
		painelCadastro.add(txtPraca);
		painelCadastro.add(lblData);
		painelCadastro.add(btnNovo);
		painelCadastro.add(btnEditar);
		painelCadastro.add(btnCancelar);
		painelCadastro.add(btnSalvar);

	}
}
