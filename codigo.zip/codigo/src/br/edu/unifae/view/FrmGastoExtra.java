package br.edu.unifae.view;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FrmGastoExtra extends JInternalFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtRazaoSocial;
	private JTextField txtNotaFiscal;
	private JTextField txtValor;
	private JLabel lblRazoSocial;
	private JLabel lblNotaFiscal;
	private JLabel lblValor;
	private JLabel lblData;
	private JButton btnNovo;
	private JButton btnSalvar;
	private JButton btnEditar;
	private JButton btnCancelar;

	/**
	 * Create the frame.
	 */
	public FrmGastoExtra() {
		super("Cadastro Gasto Extra", false, true, false, false);

		// Aqui sera informado a posicao inicial do formulario
		int inset = 100;

		setDefaultCloseOperation(FrmMenuPrincipal.DISPOSE_ON_CLOSE);

		@SuppressWarnings("unused")
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(inset, inset, 728, 488);

		JPanel painelCadastro = new JPanel();
		painelCadastro.setBounds(10, 11, 414, 248);
		getContentPane().add(painelCadastro);
		painelCadastro.setLayout(null);

		lblRazoSocial = new JLabel("Raz�o Social");
		lblRazoSocial.setBounds(15, 42, 60, 14);
		painelCadastro.add(lblRazoSocial);

		lblNotaFiscal = new JLabel("Nota Fiscal");
		lblNotaFiscal.setBounds(15, 77, 52, 14);
		painelCadastro.add(lblNotaFiscal);

		lblValor = new JLabel("Valor");
		lblValor.setBounds(15, 115, 24, 14);
		painelCadastro.add(lblValor);
		
		lblData = new JLabel("Data");
		lblData.setBounds(15, 150, 23, 14);
		painelCadastro.add(lblData);
		
		btnNovo = new JButton("Novo");
		btnNovo.setBounds(60, 308, 57, 23);
		painelCadastro.add(btnNovo);
		
		btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(214, 308, 75, 23);
		painelCadastro.add(btnCancelar);
		
		btnEditar = new JButton("Editar");
		btnEditar.setBounds(135, 308, 61, 23);
		painelCadastro.add(btnEditar);

		btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(307, 308, 63, 23);
		painelCadastro.add(btnSalvar);

		txtRazaoSocial = new JTextField();
		txtRazaoSocial.setBounds(93, 36, 279, 20);
		painelCadastro.add(txtRazaoSocial);

		txtNotaFiscal = new JTextField();
		txtNotaFiscal.setBounds(93, 74, 172, 20);
		painelCadastro.add(txtNotaFiscal);

		txtValor = new JTextField();
		txtValor.setBounds(93, 112, 86, 20);
		painelCadastro.add(txtValor);

	}
}
