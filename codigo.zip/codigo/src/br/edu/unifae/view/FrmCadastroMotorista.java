package br.edu.unifae.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.LineBorder;
import javax.swing.text.MaskFormatter;

import org.jdesktop.swingx.JXDatePicker;

import br.edu.unifae.controller.ControleDeMotoristas;
import br.edu.unifae.controller.validacaoDeDados.LetrasGrandes;
import br.edu.unifae.controller.validacaoDeDados.MotoristaBO;
import br.edu.unifae.controller.validacaoDeDados.SomenteNumeros;
import br.edu.unifae.controller.validacaoDeDados.ValidacaoException;
import br.edu.unifae.model.Motorista;
import br.edu.unifae.modelo.enumerados.EnumMotorista;
import br.edu.unifae.view.modeloJTable.MotoristasTableModel;
import javax.swing.border.BevelBorder;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class FrmCadastroMotorista extends JInternalFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8949194523365884907L;
	private JButton btnCancelar;
	private final ButtonGroup grpSexo = new ButtonGroup();
	private JComboBox<EnumMotorista> jcmbStatusMotorista;
	private JTextField jtxtCelular;
	private JTextField jtxtCNH;
	private JTextField jtxtCPF;
	private JTextField jtxtNome;
	private JTextField jtxtRG;
	private JTextField jtxtTelefone;
	private JLabel label;
	private JLabel label_1;
	private static JTable table;
	private JLabel label_2;
	private JLabel lblCelular;
	private JLabel lblCnh;
	private JLabel lblCPF;
	private JLabel lblDataNascimento;
	private JLabel lblNome;
	private JLabel lblOrgaoExpedidor;
	private JLabel lblRg;
	private JLabel lblSexo;
	private JLabel lblStatus;
	private JLabel lblTelefone;
	private SomenteNumeros numero = new SomenteNumeros();
	private LetrasGrandes letraGrandes = new LetrasGrandes();
	private JPanel painelCadastro;
	private JXDatePicker picker;
	private JRadioButton rbtFeminino;
	private JRadioButton rbtMasculino;
	private JTabbedPane tbbAbas;
	private JPanel panel;
	private JButton btnNovo;
	private JButton btnEditar;
	private JButton btnSalvar;
	private JTextField jtxtOrgaoExpedidor;
	private static SimpleDateFormat dateformat = new SimpleDateFormat("dd/MM/yyyy");
	private JPanel painelListagem;
	private JScrollPane scrollPane;
	private JTextField jtxtPesquisar;
	private JLabel lblPesquisar;
	private JComboBox<EnumMotorista> jcmbModoPesquisa;
	private JButton jBtnPesquisar;
	private JButton btnLimparFiltro;
	private JComboBox<EnumMotorista> jcmbPesquisaStatus;
	private ControleDeMotoristas motoristas = new ControleDeMotoristas();
	private JPopupMenu popupMenu;

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public FrmCadastroMotorista() throws ParseException {
		super("Cadastro Motorista", false, true, false, false);

		// Aqui sera dado o tamanho do formulario.
		int inset = 100;

		setDefaultCloseOperation(FrmMenuPrincipal.DISPOSE_ON_CLOSE);

		// Aqui esta o tutorial para utilizar o JInternalFrame -
		// https://luizgustavoss.wordpress.com/2008/11/07/exemplo-de-jinternalframe/
		@SuppressWarnings("unused")
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(inset, inset, 728, 488);
		tbbAbas = new JTabbedPane(JTabbedPane.TOP);
		tbbAbas.setBounds(2, 2, 696, 445);
		getContentPane().add(tbbAbas);

		painelCadastro = new JPanel();
		painelCadastro.setBorder(new BevelBorder(BevelBorder.LOWERED, new Color(0, 0, 0), null, null, null));
		tbbAbas.addTab("Cadastro", null, painelCadastro, null);
		painelCadastro.setLayout(null);

		lblNome = new JLabel("Nome");

		lblNome.setBounds(10, 28, 46, 14);
		painelCadastro.add(lblNome);

		lblCPF = new JLabel("CPF");
		lblCPF.setBounds(10, 70, 46, 14);
		painelCadastro.add(lblCPF);

		lblCnh = new JLabel("CNH");
		lblCnh.setBounds(10, 112, 46, 14);
		painelCadastro.add(lblCnh);

		lblCelular = new JLabel("Celular");
		lblCelular.setBounds(10, 154, 73, 14);
		painelCadastro.add(lblCelular);

		lblOrgaoExpedidor = new JLabel("Org�o Expedidor");
		lblOrgaoExpedidor.setBounds(10, 196, 117, 14);
		painelCadastro.add(lblOrgaoExpedidor);

		lblTelefone = new JLabel("Telefone");
		lblTelefone.setBounds(387, 157, 81, 14);
		painelCadastro.add(lblTelefone);

		jtxtNome = new JTextField();
		jtxtNome.setEnabled(false);
		jtxtNome.addKeyListener(letraGrandes);
		jtxtNome.setBounds(123, 28, 209, 25);
		painelCadastro.add(jtxtNome);

		jtxtCPF = new JFormattedTextField(new MaskFormatter("###.####.###-##"));
		jtxtCPF.setEnabled(false);
		jtxtCPF.setBounds(123, 75, 124, 25);
		jtxtCPF.addKeyListener(numero);
		painelCadastro.add(jtxtCPF);

		jtxtCNH = new JTextField();
		jtxtCNH.setEnabled(false);
		jtxtCNH.setBounds(123, 112, 209, 25);
		painelCadastro.add(jtxtCNH);

		jtxtCelular = new JTextField();
		jtxtCelular.setEnabled(false);
		jtxtCelular.setBounds(124, 149, 209, 25);
		jtxtCelular.setColumns(10);
		jtxtCelular.addKeyListener(numero);
		painelCadastro.add(jtxtCelular);

		jtxtTelefone = new JFormattedTextField(new MaskFormatter("(##)####-####"));
		jtxtTelefone.setEnabled(false);
		jtxtTelefone.setBounds(486, 149, 151, 25);
		jtxtTelefone.addKeyListener(numero);
		painelCadastro.add(jtxtTelefone);

		lblDataNascimento = new JLabel("Data Nascimento");
		lblDataNascimento.setBounds(387, 31, 102, 14);
		painelCadastro.add(lblDataNascimento);

		picker = new JXDatePicker();
		picker.setEnabled(false);
		picker.setBounds(499, 28, 138, 25);
		numero = new SomenteNumeros();

		picker.setDate(Calendar.getInstance().getTime());
		picker.addKeyListener(numero);
		picker.setFormats(new SimpleDateFormat("dd/MM/yyyy"));
		painelCadastro.add(picker);

		lblRg = new JLabel("RG");
		lblRg.setBounds(387, 73, 67, 14);
		painelCadastro.add(lblRg);

		jtxtRG = new JTextField();
		jtxtRG.setEnabled(false);
		jtxtRG.setBounds(486, 67, 151, 25);
		painelCadastro.add(jtxtRG);

		lblStatus = new JLabel("Status");
		lblStatus.setBounds(387, 115, 67, 14);
		painelCadastro.add(lblStatus);

		jcmbStatusMotorista = new JComboBox<EnumMotorista>();
		jcmbStatusMotorista.setEnabled(false);
		jcmbStatusMotorista.setBounds(486, 108, 151, 23);
		jcmbStatusMotorista.setModel(new DefaultComboBoxModel<EnumMotorista>(EnumMotorista.values()));
		jcmbStatusMotorista.setSelectedIndex(1);
		painelCadastro.add(jcmbStatusMotorista);

		lblSexo = new JLabel("Sexo");
		lblSexo.setBounds(10, 217, 55, 16);
		painelCadastro.add(lblSexo);

		rbtMasculino = new JRadioButton("Masculino");
		rbtMasculino.setEnabled(false);
		rbtMasculino.setBounds(10, 238, 118, 23);
		painelCadastro.add(rbtMasculino);
		rbtMasculino.setSelected(true);
		grpSexo.add(rbtMasculino);

		rbtFeminino = new JRadioButton("Feminino");
		rbtFeminino.setEnabled(false);
		rbtFeminino.setBounds(136, 238, 111, 23);
		painelCadastro.add(rbtFeminino);
		grpSexo.add(rbtFeminino);

		label = new JLabel("*");
		label.setBounds(112, 33, 13, 14);
		painelCadastro.add(label);

		label_1 = new JLabel("*");
		label_1.setBounds(112, 78, 13, 14);
		painelCadastro.add(label_1);

		label_2 = new JLabel("*");
		label_2.setBounds(112, 115, 13, 14);
		painelCadastro.add(label_2);

		panel = new JPanel();
		panel.setBounds(10, 373, 671, 33);
		painelCadastro.add(panel);

		btnNovo = new JButton("Novo");
		btnNovo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				habilitaCampos();

			}
		});
		panel.add(btnNovo);

		btnEditar = new JButton("Editar");
		btnEditar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				habilitaCampos();
			}
		});
		panel.add(btnEditar);

		btnCancelar = new JButton("Cancelar");
		btnCancelar.setEnabled(false);
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				desabilitaCancelarSalvar();

			}
		});
		panel.add(btnCancelar);

		btnSalvar = new JButton("Salvar");
		btnSalvar.setEnabled(false);
		salvarCadastro(btnSalvar);
		panel.add(btnSalvar);

		jtxtOrgaoExpedidor = new JTextField();
		jtxtOrgaoExpedidor.setEnabled(false);
		jtxtOrgaoExpedidor.setBounds(123, 191, 209, 25);
		painelCadastro.add(jtxtOrgaoExpedidor);

		painelListagem = new JPanel();
		tbbAbas.addTab("Exibi��o", null, painelListagem, null);
		painelListagem.setLayout(null);

		table = new JTable();
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setFillsViewportHeight(true);
		// por padr�o, vem sem bordas, ent�o colocamos:
		table.setBorder(new LineBorder(Color.black));
		table.setGridColor(Color.black);
		table.setShowGrid(true);

		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(10, 48, 671, 359);
		painelListagem.add(scrollPane);

		scrollPane.setViewportView(table);
		
		popupMenu = new JPopupMenu();
		addPopup(table, popupMenu);
		
		JMenuItem mntmEditar = new JMenuItem("Editar");
		mntmEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		popupMenu.add(mntmEditar);

		jtxtPesquisar = new JTextField();
		jtxtPesquisar.setBounds(240, 10, 189, 25);
		painelListagem.add(jtxtPesquisar);
		jtxtPesquisar.setColumns(10);

		lblPesquisar = new JLabel("Pesquisar por:");
		lblPesquisar.setBounds(10, 14, 97, 14);
		painelListagem.add(lblPesquisar);

		opcaoPesquisarPorStatus();
		jcmbModoPesquisa.setModel(new DefaultComboBoxModel(new String[] { "Nome", "Status", "CPF" }));
		jcmbModoPesquisa.setBounds(91, 10, 139, 25);
		painelListagem.add(jcmbModoPesquisa);

		jBtnPesquisar = funcaoPesquisar(jcmbModoPesquisa);
		jBtnPesquisar.setBounds(442, 9, 115, 25);
		painelListagem.add(jBtnPesquisar);

		btnLimparFiltro = botaoLimparFiltros();
		btnLimparFiltro.setBounds(567, 10, 110, 25);
		painelListagem.add(btnLimparFiltro);

		jcmbPesquisaStatus = new JComboBox<EnumMotorista>();
		jcmbPesquisaStatus.setBounds(240, 10, 189, 25);
		painelListagem.add(jcmbPesquisaStatus);
		jcmbPesquisaStatus.setModel(new DefaultComboBoxModel<EnumMotorista>(EnumMotorista.values()));
		jcmbPesquisaStatus.setVisible(false);
	}

	private void salvarCadastro(JButton jButton) {
		jButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				MotoristaBO motoristaBO = new MotoristaBO();
				ControleDeMotoristas motoristas = new ControleDeMotoristas();
				Motorista motorista = new Motorista();
				try {
					preencheDadosMotorista(motoristaBO, motorista);

					motoristas.cadastrarMotorista(motorista);
					JOptionPane.showMessageDialog(rootPane,
							"Motorista: " + motorista.getNome() + ", cadastrado com sucesso!");
					MotoristasTableModel ntm = new MotoristasTableModel(motoristas.listarTodosMotoristas());
					table.setModel(ntm);
					desabilitaCancelarSalvar();
					limpaCampos();
				} catch (Exception excessao) {
					JOptionPane.showMessageDialog(rootPane, "Ocorreu um erro: " + excessao.getMessage());
				}
			}
		});
	}

	/**
	 * Ao pressionar o bot�o � limpo o campo de texto pesquisa e mostra todos os
	 * itens ao usuario
	 * 
	 * @return
	 */
	private JButton botaoLimparFiltros() {
		JButton btnLimparFiltro = new JButton("limpar Filtro");
		btnLimparFiltro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jtxtPesquisar.setText("");
				MotoristasTableModel ntm = new MotoristasTableModel(motoristas.listarTodosMotoristas());
				table.setModel(ntm);
			}
		});
		return btnLimparFiltro;
	}

	/**
	 * O usuario ira procurar o metodo de pesquisa, caso o metodo for por status
	 * sera escondido o campo pesquisar e ficara aparecera o combobox busca por
	 * status. Ao selecionar outra opcao o combobox fica invisivel pro campo
	 * pesquisa ficar a mostra
	 */
	private void opcaoPesquisarPorStatus() {
		jcmbModoPesquisa = new JComboBox<EnumMotorista>();
		jcmbModoPesquisa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (jcmbModoPesquisa.getSelectedItem().equals("Status")) {
					jcmbPesquisaStatus.setVisible(true);
					jtxtPesquisar.setVisible(false);
				} else {
					jcmbPesquisaStatus.setVisible(false);
					jtxtPesquisar.setVisible(true);
				}
			}
		});
	}

	/**
	 * Funcao pesquisar coletara um Enum de motorista para pode fazer as buscas
	 * 
	 * @param jcmbModoPesquisa
	 * @return
	 */
	private JButton funcaoPesquisar(@SuppressWarnings("rawtypes") JComboBox jcmbModoPesquisa) {
		JButton jBtnPesquisar = new JButton("Pesquisar");
		jBtnPesquisar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (jcmbModoPesquisa.getSelectedItem().equals("Nome")) {
					Motorista buscarPorNome = motoristas.buscarPorNome(jtxtPesquisar.getText());
					if (buscarPorNome != null) {
						populaTabela(buscarPorNome);
					} else {
						mensagemDeErro();
					}
				} else if (jcmbModoPesquisa.getSelectedItem().equals("CPF")) {
					Motorista buscarCPF = motoristas.buscarCPF(jtxtPesquisar.getText());
					if (buscarCPF != null) {
						populaTabela(buscarCPF);
					} else {
						mensagemDeErro();
					}
				} else if (jcmbModoPesquisa.getSelectedItem().equals("Status")) {
					List<Motorista> buscaPorStatus = motoristas
							.buscaPorStatus((EnumMotorista) jcmbPesquisaStatus.getSelectedItem());
					if (!buscaPorStatus.isEmpty()) {
						MotoristasTableModel ntm = new MotoristasTableModel(buscaPorStatus);
						table.setModel(ntm);
					} else {
						mensagemDeErro();
					}

				}
			}

			private void populaTabela(Motorista dadosMotoristas) {
				List<Motorista> retornoDeDados = Arrays.asList(dadosMotoristas);
				MotoristasTableModel ntm = new MotoristasTableModel(retornoDeDados);
				table.setModel(ntm);
			}
		});
		return jBtnPesquisar;
	}

	private void mensagemDeErro() {
		JOptionPane.showMessageDialog(FrmCadastroMotorista.this,
				"Nao h� dados a serem exibidos, com o criteiro procurado", "Pesquisa Motorista",
				JOptionPane.ERROR_MESSAGE);
	}

	private void limpaCampos() {
		jtxtCelular.setText("");
		jtxtNome.setText("");
		jtxtCPF.setText("");
		jtxtTelefone.setText("");
		jtxtCNH.setText("");
		jtxtRG.setText("");
	}

	private void desabilitaCancelarSalvar() {
		btnCancelar.setEnabled(false);
		btnSalvar.setEnabled(false);
		btnNovo.setEnabled(true);
		btnEditar.setEnabled(true);
		jtxtFieldsDesativados();
		limpaCampos();
	}

	private void habilitaCampos() {
		btnCancelar.setEnabled(true);
		btnSalvar.setEnabled(true);
		btnNovo.setEnabled(false);
		btnEditar.setEnabled(false);
		jtxtFieldsAtivos();
	}

	private void jtxtFieldsDesativados() {
		jtxtCelular.setEnabled(false);
		jtxtNome.setEnabled(false);
		jtxtCPF.setEnabled(false);
		jtxtOrgaoExpedidor.setEnabled(false);
		jtxtTelefone.setEnabled(false);
		picker.setEnabled(false);
		jcmbStatusMotorista.setEnabled(false);
		jtxtCNH.setEnabled(false);
		jtxtRG.setEnabled(false);
		rbtFeminino.setEnabled(false);
		rbtMasculino.setEnabled(false);
	}

	private void jtxtFieldsAtivos() {
		jtxtCelular.setEnabled(true);
		jtxtNome.setEnabled(true);
		jtxtCPF.setEnabled(true);
		jtxtOrgaoExpedidor.setEnabled(true);
		jtxtTelefone.setEnabled(true);
		picker.setEnabled(true);
		jcmbStatusMotorista.setEnabled(true);
		jtxtCNH.setEnabled(true);
		jtxtRG.setEnabled(true);
		rbtFeminino.setEnabled(true);
		rbtMasculino.setEnabled(true);
	}

	private void preencheDadosMotorista(MotoristaBO motoristaBO, Motorista motorista)
			throws ValidacaoException, ParseException {
		String dtNasc = picker.getEditor().getText();
		motoristaBO.validarNome(jtxtNome.getText());
		motoristaBO.validarCNH(jtxtCNH.getText());

		motorista.setNome(jtxtNome.getText());
		motorista.setCpf(jtxtCPF.getText());
		motorista.setCnh(jtxtCNH.getText());
		motorista.setDataDeNascimento(dateformat.parse(dtNasc));
		motorista.setTelefone(jtxtTelefone.getText());
		char sexo = rbtMasculino.isSelected() ? 'M' : 'F';
		motorista.setSexo(sexo);
		motorista.setRg(jtxtRG.getText());
		motorista.setOrgaoExpedidor(jtxtOrgaoExpedidor.getText());
		motorista.setCelular(jtxtCelular.getText());
		motorista.setStatus((EnumMotorista) jcmbStatusMotorista.getSelectedItem());
	}
	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}
