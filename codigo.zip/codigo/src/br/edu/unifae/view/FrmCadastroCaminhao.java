package br.edu.unifae.view;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;

import br.edu.unifae.modelo.enumerados.EnumCaminhao;
import br.edu.unifae.modelo.enumerados.EnumMotorista;

public class FrmCadastroCaminhao extends JInternalFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTabbedPane tbbAbas;
	private JPanel painelCadastro;
	private JTextField jtxtChassi;
	private JTextField jtxtPlaca;
	private JTextField jtxtOdometro;
	private JLabel lblOdometro;
	private JTextField jtxtModelo;
	private JTextField jtxtConsumoKM;
	private JLabel lblModelo;
	private JLabel lblFabricante;
	private JTextField jtxtFabricante;
	private JTextField jtxtRenavam;
	private JLabel lblRenavam;
	private JComboBox jcmbAnoFabricacao;
	private JLabel lblAno;
	private JButton btnNovo;
	private JButton btnSalvar;
	private JButton btnEditar;
	private JButton btnCancelar;
	private JPanel painelListagem;
	private JPanel panel;
	private JTable table;
	private JScrollPane scrollPane;
	private JTextField jtxtPesquisar;
	private JLabel lblPesquisar;
	@SuppressWarnings("unused")
	private Container container;
	private JComboBox<EnumCaminhao> jcmbPesquisaStatus;
	private JComboBox jcmbModoPesquisa;
	private JButton btnLimparFiltro;
	private JButton jBtnPesquisar;
	private JComboBox<EnumCaminhao> jcmbStatus;

	public FrmCadastroCaminhao() {
		super("Cadastro Caminh�o", false, true, false, false);

		// Aqui sera dado o tamanho do formulario.
		int inset = 50;

		setDefaultCloseOperation(FrmMenuPrincipal.DISPOSE_ON_CLOSE);

		// Aqui esta o tutorial para utilizar o JInternalFrame -
		// https://luizgustavoss.wordpress.com/2008/11/07/exemplo-de-jinternalframe/
		@SuppressWarnings("unused")
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(inset, inset, 711, 488);

		container = getContentPane();
		getContentPane().setLayout(null);

		tbbAbas = new JTabbedPane();
		tbbAbas.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		tbbAbas.setBounds(2, 2, 696, 445);
		getContentPane().add(tbbAbas);

		painelCadastro();
		painelListagem();

	}

	private void painelListagem() {
		painelListagem = new JPanel();
		tbbAbas.addTab("Exibi��o", null, painelListagem, null);
		painelListagem.setLayout(null);

		table = new JTable();
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setFillsViewportHeight(true);
		// por padr�o, vem sem bordas, ent�o colocamos:
		table.setBorder(new LineBorder(Color.black));
		table.setGridColor(Color.black);
		table.setShowGrid(true);

		scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(10, 48, 671, 359);
		painelListagem.add(scrollPane);

		scrollPane.setViewportView(table);

		jtxtPesquisar = new JTextField();
		jtxtPesquisar.setBounds(240, 10, 189, 25);
		painelListagem.add(jtxtPesquisar);
		jtxtPesquisar.setColumns(10);

		lblPesquisar = new JLabel("Pesquisar por:");
		lblPesquisar.setBounds(10, 14, 97, 14);
		painelListagem.add(lblPesquisar);

		opcaoPesquisarPorStatus();
		jcmbModoPesquisa.setModel(new DefaultComboBoxModel(new String[] { "Placa", "Status" }));
		jcmbModoPesquisa.setBounds(91, 10, 139, 25);
		painelListagem.add(jcmbModoPesquisa);

		jBtnPesquisar = new JButton("Pesquisar");
		jBtnPesquisar.setBounds(442, 9, 115, 25);
		painelListagem.add(jBtnPesquisar);

		btnLimparFiltro = new JButton("Limpar Filtros");
		btnLimparFiltro.setBounds(567, 10, 110, 25);
		painelListagem.add(btnLimparFiltro);

		jcmbPesquisaStatus = new JComboBox<EnumCaminhao>();
		jcmbPesquisaStatus.setBounds(240, 10, 189, 25);
		painelListagem.add(jcmbPesquisaStatus);
		jcmbPesquisaStatus.setModel(new DefaultComboBoxModel(EnumCaminhao.values()));
		jcmbPesquisaStatus.setVisible(false);
	}

	private void painelCadastro() {
		painelCadastro = new JPanel();
		painelCadastro.setBorder(new BevelBorder(BevelBorder.LOWERED, Color.DARK_GRAY, null, null, null));
		tbbAbas.addTab("Cadastro", null, painelCadastro, null);
		painelCadastro.setLayout(null);

		jtxtChassi = new JTextField();
		jtxtChassi.setEnabled(false);
		jtxtChassi.setBounds(387, 56, 86, 25);
		painelCadastro.add(jtxtChassi);
		jtxtChassi.setColumns(10);

		JLabel lblChassi = new JLabel("Chassi");
		lblChassi.setBounds(331, 67, 46, 14);
		painelCadastro.add(lblChassi);

		JLabel jlblPlaca = new JLabel("Placa");
		jlblPlaca.setBounds(10, 31, 46, 14);
		painelCadastro.add(jlblPlaca);

		jtxtPlaca = new JTextField();
		jtxtPlaca.setEnabled(false);
		jtxtPlaca.setBounds(78, 28, 86, 25);
		painelCadastro.add(jtxtPlaca);

		JLabel lblConsumoKm = new JLabel("Consumo KM");
		lblConsumoKm.setBounds(10, 67, 77, 14);
		painelCadastro.add(lblConsumoKm);

		jtxtOdometro = new JTextField();
		jtxtOdometro.setEnabled(false);
		jtxtOdometro.setBounds(235, 56, 86, 25);
		painelCadastro.add(jtxtOdometro);
		jtxtOdometro.setColumns(10);

		lblOdometro = new JLabel("Odometro");
		lblOdometro.setBounds(174, 67, 66, 14);
		painelCadastro.add(lblOdometro);

		jcmbStatus = new JComboBox<EnumCaminhao>();
		jcmbStatus.setBounds(460, 87, 164, 25);
		jcmbStatus.setModel(new DefaultComboBoxModel<EnumCaminhao>(EnumCaminhao.values()));
		painelCadastro.add(jcmbStatus);

		jtxtModelo = new JTextField();
		jtxtModelo.setEnabled(false);
		jtxtModelo.setBounds(578, 26, 86, 25);
		painelCadastro.add(jtxtModelo);
		jtxtModelo.setColumns(10);

		jtxtConsumoKM = new JTextField();
		jtxtConsumoKM.setEnabled(false);
		jtxtConsumoKM.setBounds(78, 56, 86, 25);
		painelCadastro.add(jtxtConsumoKM);
		jtxtConsumoKM.setColumns(10);

		lblModelo = new JLabel("Modelo");
		lblModelo.setBounds(482, 31, 46, 14);
		painelCadastro.add(lblModelo);

		lblFabricante = new JLabel("Fabricante");
		lblFabricante.setBounds(331, 31, 66, 14);
		painelCadastro.add(lblFabricante);

		jtxtFabricante = new JTextField();
		jtxtFabricante.setEnabled(false);
		jtxtFabricante.setBounds(386, 28, 86, 25);
		painelCadastro.add(jtxtFabricante);
		jtxtFabricante.setColumns(10);

		JLabel lblSituaco = new JLabel("Situa��o");
		lblSituaco.setBounds(397, 90, 46, 14);
		painelCadastro.add(lblSituaco);

		jtxtRenavam = new JTextField();
		jtxtRenavam.setEnabled(false);
		jtxtRenavam.setBounds(578, 56, 86, 25);
		painelCadastro.add(jtxtRenavam);
		jtxtRenavam.setColumns(10);

		lblRenavam = new JLabel("Renavam");
		lblRenavam.setBounds(483, 67, 83, 14);
		painelCadastro.add(lblRenavam);

		jcmbAnoFabricacao = new JComboBox();
		jcmbAnoFabricacao.setModel(new DefaultComboBoxModel(new String[] {"1950", "1951", "1952", "1953", "1954", "1955", "1956", "1957", "1958", "1959", "1960", "1961", "1962", "1963", "1964", "1965", "1966", "1967", "1968", "1969", "1970", "1971", "1972", "1973", "1974", "1975", "1976", "1977", "1978", "1979", "1980", "1981", "1982", "1983", "1984", "1985", "1986", "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1995", "1996", "1997", "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016"}));
		jcmbAnoFabricacao.setEnabled(false);
		jcmbAnoFabricacao.setBounds(235, 28, 86, 20);
		painelCadastro.add(jcmbAnoFabricacao);

		lblAno = new JLabel("Ano");
		lblAno.setBounds(176, 31, 46, 14);
		painelCadastro.add(lblAno);

		panel = new JPanel();
		panel.setBounds(10, 373, 671, 33);
		painelCadastro.add(panel);

		btnNovo = new JButton("Novo");
		btnNovo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				habilitaBotoes();

			}
		});
		panel.add(btnNovo);

		btnEditar = new JButton("Editar");
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		panel.add(btnEditar);

		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				desabilitaBotoes();
				
			}
		});
		btnCancelar.setEnabled(false);
		panel.add(btnCancelar);

		btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		btnSalvar.setEnabled(false);
		panel.add(btnSalvar);

	}

	private void opcaoPesquisarPorStatus() {
		jcmbModoPesquisa = new JComboBox<EnumMotorista>();
		jcmbModoPesquisa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (jcmbModoPesquisa.getSelectedItem().equals("Status")) {
					jcmbPesquisaStatus.setVisible(true);
					jtxtPesquisar.setVisible(false);
				} else {
					jcmbPesquisaStatus.setVisible(false);
					jtxtPesquisar.setVisible(true);
				}
			}
		});
	}

	public void habilitarCampos() {
		jtxtChassi.setEnabled(true);
		jtxtPlaca.setEnabled(true);
		jtxtOdometro.setEnabled(true);
		jtxtModelo.setEnabled(true);
		jtxtConsumoKM.setEnabled(true);
		jtxtFabricante.setEnabled(true);
		jtxtRenavam.setEnabled(true);
		jcmbAnoFabricacao.setEnabled(true);
		jtxtPesquisar.setVisible(true);
		jcmbStatus.setEnabled(true);


	}	public void desabilitarCampos() {
		jtxtChassi.setEnabled(false);
		jtxtPlaca.setEnabled(false);
		jtxtOdometro.setEnabled(false);
		jtxtModelo.setEnabled(false);
		jtxtConsumoKM.setEnabled(false);
		jtxtFabricante.setEnabled(false);
		jtxtRenavam.setEnabled(false);
		jcmbAnoFabricacao.setEnabled(false);
		jtxtPesquisar.setEnabled(false);
		jcmbStatus.setEnabled(false);

	}
	
	private void desabilitaBotoes() {
		btnCancelar.setEnabled(false);
		btnSalvar.setEnabled(false);
		btnNovo.setEnabled(true);
		btnEditar.setEnabled(true);
		desabilitarCampos();
		limpaCampos();
	}

	private void habilitaBotoes() {
		btnCancelar.setEnabled(true);
		btnSalvar.setEnabled(true);
		btnNovo.setEnabled(false);
		btnEditar.setEnabled(false);
		habilitarCampos();
	}
	
	public void limpaCampos(){
		jtxtChassi.setText("");
		jtxtPlaca.setText("");
		jtxtOdometro.setText("");
		jtxtModelo.setText("");
		jtxtConsumoKM.setText("");
		jtxtFabricante.setText("");
		jtxtRenavam.setText("");
		jcmbAnoFabricacao.setSelectedIndex(-1);
		jtxtPesquisar.setText("");
		jcmbStatus.setSelectedIndex(-1);

	}
	
}