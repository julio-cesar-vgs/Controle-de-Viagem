package br.edu.unifae.view.modeloJTable;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import br.edu.unifae.model.Caminhao;

public class VeiculosTableModel extends AbstractTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<Caminhao> caminhoes;

	public VeiculosTableModel(List<Caminhao> caminhoes) {
		this.caminhoes = caminhoes;
	}

	@Override
	public int getColumnCount() {
		return 10;
	}

	@Override
	public int getRowCount() {
		return caminhoes.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Caminhao caminhao = caminhoes.get(rowIndex);

		switch (columnIndex) {
		case 0:
			return caminhao.getPlaca();
		case 1:
			return caminhao.getModelo();
		case 2:
			return caminhao.getAnoModelo();
		case 3:
			return caminhao.getChassi();
		case 4:
			return caminhao.getOdometro();
		case 5:
			return caminhao.getRenavam();
		case 6:
			return caminhao.getStatus();
		}
		return null;
	}

	@Override
	public String getColumnName(int columnIndex) {

		switch (columnIndex) {
		case 0:
			return "Placa";
		case 1:
			return "Modelo";
		case 2:
			return "Ano Modelo";
		case 3:
			return "Chassi";
		case 4:
			return "Odometro";
		case 5:
			return "Renavam";
		case 6:
			return "Status";
		}
		return null;
	}
}
