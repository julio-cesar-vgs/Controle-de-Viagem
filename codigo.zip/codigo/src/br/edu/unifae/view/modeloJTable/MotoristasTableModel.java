package br.edu.unifae.view.modeloJTable;

import java.text.SimpleDateFormat;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import br.edu.unifae.model.Motorista;

public class MotoristasTableModel extends AbstractTableModel {
	private static SimpleDateFormat dateformat = new SimpleDateFormat("dd/MM/yyyy");
	private List<Motorista> motoristas;

	public MotoristasTableModel(List<Motorista> motoristas) {
		this.motoristas = motoristas;
	}

	@Override
	public int getColumnCount() {
		return 10;
	}

	@Override
	public int getRowCount() {
		return motoristas.size();
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Motorista moto = motoristas.get(rowIndex);

		switch (columnIndex) {
		case 0:
			return moto.getNome();
		case 1:
			return moto.getRg();
		case 2:
			return moto.getCpf();
		case 3:
			if (moto.getDataDeNascimento() == null) {
				return moto.getDataDeNascimento();
			} else {
				return dateformat.format(moto.getDataDeNascimento());
			}
		case 4:
			return moto.getCelular();
		case 5:
			return moto.getSexo();
		case 6:
			return moto.getCnh();
		case 7:
			return moto.getOrgaoExpedidor();
		case 8:
			return moto.getStatus();
		case 9:
			return moto.getTelefone();

		}
		return null;
	}

	@Override
	public String getColumnName(int columnIndex) {

		switch (columnIndex) {
		case 0:
			return "Nome";
		case 1:
			return "RG";
		case 2:
			return "CPF";
		case 3:
			return "Data Nascimento";
		case 4:
			return "Celular";
		case 5:
			return "Sexo";
		case 6:
			return "CNH";
		case 7:
			return "Org�o Expedidor";
		case 8:
			return "Status";
		case 9:
			return "Telefone";

		}
		return null;
	}
}
