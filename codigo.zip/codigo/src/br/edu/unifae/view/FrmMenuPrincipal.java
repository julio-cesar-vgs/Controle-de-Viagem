package br.edu.unifae.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

import com.alee.laf.WebLookAndFeel;

public class FrmMenuPrincipal extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel desktopPane;
	private JMenuItem jmnMotorista, jmnCaminhao;
	private JMenuBar menuBar;
	private JMenu mnCadastro;
	private FrmCadastroMotorista frmCadastroMotorista;
	private FrmCadastroCaminhao frmCadastroCaminhao;
	private FrmGastoExtra frmGastoExtra = new FrmGastoExtra();
	private JMenuItem mntmGastoExtra;
	private FrmManutencao frmManutencao;
	private JMenuItem mntmPedagio;
	protected FrmPedagio frmPedagio;

	public FrmMenuPrincipal() {
		super("Exemplo de JDesktopPane");

		int inset = 50;

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(inset, inset, screenSize.width - inset * 2, screenSize.height - inset * 2);

		desktopPane = new JPanel();
		desktopPane.paintComponents(getGraphics());
		desktopPane.setBackground(new Color(211, 211, 211));
		jmnMotorista = new JMenuItem("Motorista");
		jmnMotorista.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent evt) {
				// Aqui sera chamado a respectiva Janela interna.
				try {
					frmCadastroMotorista = new FrmCadastroMotorista();
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				frmCadastroMotorista.setVisible(true);
				desktopPane.add(frmCadastroMotorista);
			}
		});

		jmnCaminhao = new JMenuItem("Caminhao");
		jmnCaminhao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frmCadastroCaminhao = new FrmCadastroCaminhao();
				frmCadastroCaminhao.setVisible(true);
				desktopPane.add(frmCadastroCaminhao);
			}
		});

		menuBar = new JMenuBar();
		mnCadastro = new JMenu("Cadastro");

		setContentPane(desktopPane);
		desktopPane.setLayout(null);

		mnCadastro.add(jmnMotorista);
		mnCadastro.add(jmnCaminhao);

		menuBar.add(mnCadastro);

		mntmGastoExtra = new JMenuItem("Gasto Extra");
		mntmGastoExtra.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frmGastoExtra = new FrmGastoExtra();
				frmGastoExtra.setVisible(true);
				desktopPane.add(frmGastoExtra);

			}
		});
		mnCadastro.add(mntmGastoExtra);

		JMenuItem mntmManuteno = new JMenuItem("Manuten��o");
		mntmManuteno.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				frmManutencao = new FrmManutencao();
				frmManutencao.setVisible(true);
				desktopPane.add(frmManutencao);
			}
		});
		mnCadastro.add(mntmManuteno);
		
		mntmPedagio = new JMenuItem("Pedagio");
		mntmPedagio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frmPedagio = new FrmPedagio();
				frmPedagio.setVisible(true);
				desktopPane.add(frmPedagio);
			}
		});
		mnCadastro.add(mntmPedagio);

		setJMenuBar(menuBar);

		setVisible(true);
		setResizable(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	@SuppressWarnings("unused")
	public static void main(String args[]) {

		// ha 1 arquivo externo para poder alterar a visualziacao do lookandfeel padrao.
		// com o comando abaixo, isto � feito de forma automatica.
		WebLookAndFeel.install();
		FrmMenuPrincipal p = new FrmMenuPrincipal();
	}

}
