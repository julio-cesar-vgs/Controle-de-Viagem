package br.edu.unifae.view;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

public class FrmManutencao extends JInternalFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtServico;
	private JTabbedPane tbbAbas;
	private JButton btnSalvar;
	private JLabel lblCaminhao;
	/**
	 * Create the frame.
	 */
	public FrmManutencao() {
		super("Cadastro Motorista", false, true, false, false);

		// Aqui sera dado o tamanho do formulario.
		int inset = 50;

		setDefaultCloseOperation(FrmMenuPrincipal.DISPOSE_ON_CLOSE);

		// Aqui esta o tutorial para utilizar o JInternalFrame -
		// https://luizgustavoss.wordpress.com/2008/11/07/exemplo-de-jinternalframe/
		@SuppressWarnings("unused")
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setBounds(inset, inset, 728, 488);

		tbbAbas = new JTabbedPane(JTabbedPane.TOP);
		tbbAbas.setBounds(2, 2, 696, 445);
		getContentPane().add(tbbAbas);
		
		JPanel pnlCadastrar = new JPanel();
		tbbAbas.addTab("Cadastrar", null, pnlCadastrar, null);
		pnlCadastrar.setLayout(null);
		
		JLabel lblDataDeEntrada = new JLabel("Data de Entrada");
		lblDataDeEntrada.setBounds(10, 32, 92, 14);
		pnlCadastrar.add(lblDataDeEntrada);
		
		JLabel lblDataDeSaida = new JLabel("Data de Sa\u00EDda");
		lblDataDeSaida.setBounds(10, 69, 92, 14);
		pnlCadastrar.add(lblDataDeSaida);
		
		JLabel lblServico = new JLabel("Servi\u00E7o");
		lblServico.setBounds(10, 106, 46, 14);
		pnlCadastrar.add(lblServico);
		
		lblCaminhao = new JLabel("Caminh\u00E3o");
		lblCaminhao.setBounds(10, 143, 58, 14);
		pnlCadastrar.add(lblCaminhao);
		
		txtServico = new JTextField();
		txtServico.setBounds(109, 103, 278, 20);
		pnlCadastrar.add(txtServico);
		
		JButton btnNovo = new JButton("Novo");
		btnNovo.setBounds(10, 177, 89, 23);
		pnlCadastrar.add(btnNovo);
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.setBounds(118, 177, 89, 23);
		pnlCadastrar.add(btnEditar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(217, 177, 89, 23);
		pnlCadastrar.add(btnCancelar);
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(316, 177, 89, 23);
		pnlCadastrar.add(btnSalvar);
		
		JPanel pnlExibicao = new JPanel();
		tbbAbas.addTab("Exibi\u00E7\u00E3o", null, pnlExibicao, null);
	}

}
