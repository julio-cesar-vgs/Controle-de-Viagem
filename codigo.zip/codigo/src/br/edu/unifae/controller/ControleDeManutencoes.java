package br.edu.unifae.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.edu.unifae.model.Abastecimento;
import br.edu.unifae.model.Caminhao;
import br.edu.unifae.model.GastoExtra;
import br.edu.unifae.model.Manutencao;
import br.edu.unifae.model.Viagem;
import br.edu.unifae.modelo.enumerados.EnumCaminhao;

public class ControleDeManutencoes {

	private static List<Manutencao> manutencoes = new ArrayList<>();

	public boolean cadastrarManutencao(Manutencao nova) {
		EnumCaminhao status = nova.getCaminhao().getStatus();
		
		if(status == EnumCaminhao.Disponivel) {
			nova.getCaminhao().setStatus(EnumCaminhao.Manutencao);
			return manutencoes.add(nova);			
		}
		return false;
	}
	
	/**
	 * 
	 * @param dataFinalizacao
	 * @param placa
	 * @param servico
	 */
	public void finalizarManutencao(Date dataSaida, String placa, String servico) {
		for (Manutencao manutencao : manutencoes) {
			if(manutencao.getCaminhao().getPlaca().equals(placa)) {
				if(manutencao.getCaminhao().getStatus() == EnumCaminhao.Manutencao) {
					manutencao.finalizaManutencao(dataSaida, placa, servico);
					manutencao.getCaminhao().setStatus(EnumCaminhao.Disponivel);
				}
			}
		}
	}

	public String listaManutencoes() {
		return manutencoes.toString();
	}

	/**
	 * Esta fun��o realiza uma busca de todas as manuten��es de um
	 * caminh�o, dado a placa do caminh�o desejado. 
	 * 
	 * @param placa do caminh�o
	 * @return uma lista de todas as manuten��es do caminh�o informado.
	 */
	public String listaPorCaminhao(String placa) {
		StringBuilder listaDosCaminhoes = new StringBuilder();
		
		for (Manutencao manutencao : manutencoes)
			if (placa.equals(manutencao))
				listaDosCaminhoes.append(manutencao.getCaminhao().getPlaca());

		return listaDosCaminhoes.toString();
	}

	/**
	 * Esta fun��o realiza uma busca de todas as manuten��es dada uma data
	 * inicial e final. 
	 * Seu retorno � uma String com todas as manuten��es do per�odo.
	 * 
	 * @param dataInicial - data inicial do per�odo
	 * @param dataFinal - data final do per�odo
	 * @return manuten��es - lista de todas as manuten��es entre os dois per�odos.
	 */
	public String listaPorPeriodo(Date dataInicial, Date dataFinal) {
		StringBuilder m = new StringBuilder();

		for (Manutencao manutencao : manutencoes)
			if (manutencao.getDataEntrada().equals(dataInicial) || manutencao.getDataEntrada().after(dataInicial) && 
				manutencao.getDataSaida().before(dataFinal) || manutencao.getDataSaida().equals(dataFinal))
				m.append(manutencao);

		return m.toString();
	}
}