package br.edu.unifae.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.edu.unifae.model.Abastecimento;
import br.edu.unifae.model.GastoExtra;
import br.edu.unifae.model.Pedagio;
import br.edu.unifae.model.Viagem;
import br.edu.unifae.modelo.enumerados.EnumCaminhao;
import br.edu.unifae.modelo.enumerados.EnumViagem;

public class ControleDeViagens {

	private static List<Viagem> viagens = new ArrayList<>();
	private static int total = 1;

	/**
	 * Fun��o respons�vel pelo cadastramento de uma nova viagem
	 * no sistema. 
	 * 
	 * @param nova
	 * @return true - se cadastradado com sucesso. 
	 * 		   false -  caso n�o seja poss�vel o cadastramento da viagem.
	 */
	public boolean cadastrarViagem(Viagem nova) {
		nova.setIdViagem(total++);
		return viagens.add(nova);
	}

	public Viagem buscarPorPlaca(String placa) {
		for (Viagem viagem : viagens)
			if (viagem.getCaminhao().getPlaca().equalsIgnoreCase(placa))
				return viagem;

		return null;
	}

	public void finalizarViagem(int idViagem, Date dataFinalizacao, int odometroFinal, List<Pedagio> pedagios,
		List<Abastecimento> abastecimentos, List<GastoExtra> extras) {

		for (Viagem viagem : viagens)
			if (viagem.getIdViagem() == idViagem)
				if(viagem.getStatus() == EnumViagem.Aberta) {
					viagem.finalizaViagem(dataFinalizacao, odometroFinal, pedagios, abastecimentos, extras);
					viagem.setStatus(EnumViagem.Finalizada);	
				}
	}

	/**
	 * Esta fun��o lista todas as viagens cadastradas ordenadas pelas placas
	 * dos caminh�es.
	 * 
	 * @return viagens - Um List com todas as viagens ordenadas
	 */
	public List<Viagem> listarTodasOrdenadaPorPlaca() {
		viagens.sort((u1, u2) -> u1.getCaminhao().getPlaca().compareTo(u2.getCaminhao().getPlaca()));
		return viagens;
	}

	/**
	 * Esta fun��o lista todas as viagens dada o status de pesquisa.
	 * 
	 * @param status da viagem
	 * @return todas as viagens do status passado.
	 */
	public List<Viagem> listarPorStatus(EnumViagem status) {
		List<Viagem> listaDeRetorno = new ArrayList<>();

		for (Viagem iterador : viagens)
			if (iterador.getStatus() == (status))
				listaDeRetorno.add(iterador);

		return listaDeRetorno;
	}
	
	public boolean existemViagensCadastrados() {
		if (viagens.size() > 0)
			return true;
		else
			return false;
	}
}
