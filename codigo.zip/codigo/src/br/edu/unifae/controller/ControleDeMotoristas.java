package br.edu.unifae.controller;

import static java.util.Comparator.comparing;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.edu.unifae.main.TesteMain;
import br.edu.unifae.model.Motorista;
import br.edu.unifae.modelo.enumerados.EnumMotorista;

public class ControleDeMotoristas {

	private static List<Motorista> motoristas = new ArrayList<Motorista>();
	private int total = 1;

	/**
	 * Procedimento para cadastrar um motorista.
	 * 
	 * Caso for cadastrado o motorista corretamente retornara true, caso houver
	 * algum erro retornara false;
	 * 
	 * @param Motorista
	 * @return true ou false
	 */
	public boolean cadastrarMotorista(Motorista novo) {
		novo.setId(total++);
		return motoristas.add(novo);
	}

	/**
	 * O Usuario ira informar um cpf e este procedimento verifica se este
	 * usuario existe ou nao. Caso exista retornara os dados completo do
	 * motorista. Caso nao, sera retornado um valor null.
	 * 
	 * @param CPF
	 * @return motorista.
	 */
	public Motorista buscarCPF(String cpf) {

		for (Motorista motoristaCPF : motoristas)
			if (motoristaCPF.getCpf().contains(cpf))
				return motoristaCPF;

		return null;
	}

	/**
	 * O Usuario ira informar um cpf e este procedimento verifica se este
	 * usuario existe ou nao. Caso exista retornara os dados completo do
	 * motorista. Caso nao, sera retornado um valor null.
	 * 
	 * @param nome
	 * @return motorista.
	 */
	public Motorista buscarPorNome(String nome) {

		for (Motorista nomeMotorista : motoristas)
			if (nomeMotorista.getNome().equalsIgnoreCase(nome))
				return nomeMotorista;

		return null;
	}

	/**
	 * Fun��o realiza uma busca pelo status passado de todos os motoistas.
	 * 
	 * @param status
	 *            desejado
	 * @return todos os motoristas do status informado.
	 */
	public List<Motorista> buscaPorStatus(EnumMotorista status) {
		List<Motorista> listaDeRetorno = new ArrayList<>();

		for (Motorista iterador : motoristas)
			if (iterador.getStatus() == (status))
				listaDeRetorno.add(iterador);

		return listaDeRetorno;
	}

	/**
	 * Editar motorista, apos a pesquisa pelo nome, por um metodo pelo main o
	 * usuario podera fazer as devidas alteracoes. Metodo recebe o motorista e
	 * acessa o Main.Lerdados para que possa ser feito as devidas alteracoes.
	 * 
	 * @param motorista
	 * @return true

	public boolean editarMotorista(Motorista motorista) {
		Motorista motoristaEditado = TesteMain.lerDadosDosMotoristas();

		motorista.setNome(motoristaEditado.getNome());
		motorista.setCpf(motoristaEditado.getCpf());
		motorista.setCnh(motoristaEditado.getCnh());
		motorista.setStatus(motoristaEditado.getStatus());
		return true;
	}	 */

	/**
	 * Lista todos os motoristas cadastrados.
	 * 
	 * @return todos os motoristas.
	 */
	public List<Motorista> listarTodosMotoristas() {
		return motoristas;
	}

	/**
	 * Fun��o realiza a listagem de todos os motoristas ordenados pelo nome dos
	 * mesmos.
	 * 
	 * @return todos os motoristas
	 */
	public List<Motorista> listarTodosOrdenadosPorNome() {
		motoristas.sort(comparing(u -> u.getNome()));
		return motoristas;
	}

	public Motorista buscaPorNomeEStatusDisponivel(String nomePesquisado) {

		for (int i = 0; i < motoristas.size(); i++) {
			Motorista nome = motoristas.get(i);
			if (nome.getNome().equalsIgnoreCase(nomePesquisado) && nome.getStatus().equals(EnumMotorista.Disponivel)) {
				return nome;
			}
		}
		return null;
	}

	/**
	 * Esta fun��o realiza a altera��o do status dado o motorista e o status
	 * desejado. Caso seja passado um status inv�lido/inexistente o status ser�
	 * alterado para o padr�o dispon�vel.
	 * 
	 * @param motoristaASerEditado
	 * @param status
	 */
	public static void statusMotorista(Motorista motoristaASerEditado, byte status) {
		switch (status) {
		case 1:
			motoristaASerEditado.setStatus(EnumMotorista.Aposentado);
			break;

		case 2:
			motoristaASerEditado.setStatus(EnumMotorista.Disponivel);
			break;

		case 3:
			motoristaASerEditado.setStatus(EnumMotorista.Ferias);
			break;

		case 4:
			motoristaASerEditado.setStatus(EnumMotorista.Indisponivel);
			break;

		default:
			JOptionPane.showMessageDialog(null, "Op��o Inv�lida. Por padr�o, o mesmo ficar� Dispon�vel.");
			motoristaASerEditado.setStatus(EnumMotorista.Disponivel);
			break;
		}
	}
}
