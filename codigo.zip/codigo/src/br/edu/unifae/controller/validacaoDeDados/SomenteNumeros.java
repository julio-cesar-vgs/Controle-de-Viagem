package br.edu.unifae.controller.validacaoDeDados;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTextField;

public class SomenteNumeros implements KeyListener{

	@Override
	public void keyPressed(KeyEvent e) {
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		char tecla = e.getKeyChar();
		if (!(Character.isDigit(tecla))) {
			e.consume();
		}
	}

}
