package br.edu.unifae.controller.validacaoDeDados;

import br.edu.unifae.controller.ControleDeCaminhoes;

public class CaminhaoBO {

	public boolean validarPlaca(String placaCaminhao) throws ValidacaoException{
		boolean ehValido = true;
		
		if(placaCaminhao.isEmpty() || placaCaminhao.equals("")) {
			ehValido = false;
			throw new ValidacaoException("Este campo nao pode ser vazio");
		} 
		
		if(placaCaminhao.length() > 7) {
			ehValido = false;
			throw new ValidacaoException("Campo Placa comporta no m�ximo 7 chars!");
		}
		
		return ehValido;
	}

	public boolean validaOdometro(int odometro) throws ValidacaoException  {
		boolean ehValido = true;
		
		if (odometro < 0) {
			ehValido = false;
			throw new ValidacaoException("Campo ODOM�TRO deve ser positivo.");
		}
		
		return ehValido;
	}

	public boolean validarRenavam(String renavam) throws ValidacaoException {
		char[] digitos = renavam.toCharArray();
		boolean ehValido = true;
		
		if (renavam.equals("") || renavam.isEmpty()) {
			ehValido = false;
			throw new ValidacaoException("Campo RENAVAM n�o pode ser vazio.");
		} 
		
		if (renavam.length() != 11) {
			ehValido = false;
			throw new ValidacaoException("Campo RENAVAM deve ter 11 Digitos.");
		}
		
		for (char digito : digitos) {
			if (!Character.isDigit(digito)) {
				ehValido = false;
				throw new ValidacaoException("Campo CPF � somente num�rico.");
			}
		}
		
		return ehValido;
	}

}