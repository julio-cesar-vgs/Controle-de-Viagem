package br.edu.unifae.controller.validacaoDeDados;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTextField;

public class LetrasGrandes implements KeyListener {

	// veta a utilizacao de numeros
	@Override
	public void keyPressed(KeyEvent e) {
		JTextField source = (JTextField) e.getSource();
		String data = source.getText();
		source.setText("");
		source.validate();
		data = data.toUpperCase();
		source.setText(data);
		source.validate();

	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

	// Veta a utiliza��o de numeros 
	@Override
	public void keyTyped(KeyEvent e) {
		char tecla = e.getKeyChar();
		if (!(Character.isAlphabetic(tecla))) {
			e.consume();
		}
	}

}
