package br.edu.unifae.controller.validacaoDeDados;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

import br.edu.unifae.model.Motorista;

// MotoristaBO = business Object 
public class MotoristaBO {
	// Classe responsavel pela valida��o dos dados.

	private DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

	public boolean validarNome(String nome) throws ValidacaoException {
		boolean ehValido = true;

		if (nome.isEmpty() || nome.equals("")) {
			ehValido = false;
			throw new ValidacaoException("Campo NOME obrigat�rio.");
		}

		if (nome.length() > 30) {
			ehValido = false;
			throw new ValidacaoException("Campo NOME possui um limite de 30 caracteres.");
		}

		return ehValido;
	}

	public boolean validarCPF(String cpf) throws ValidacaoException {

		char[] digitos = cpf.toCharArray();
		boolean ehValido = true;

		if (cpf.isEmpty() || cpf.equals("")) {
			ehValido = false;
			throw new ValidacaoException("Campo CPF Obrigat�rio!");
		}

		for (char digito : digitos) {
			if (!Character.isDigit(digito)) {
				ehValido = false;
				throw new ValidacaoException("Campo CPF N�o Aceita Letras");
			}
		}
		if (cpf.length() != 11) {
			ehValido = false;
			throw new ValidacaoException("Campo CPF deve ter 11 d�gitos!");
		}

		return ehValido;
	}

	public boolean validarCNH(String cnh) throws ValidacaoException {
		boolean ehValido = true;

		if (cnh.isEmpty() || cnh.equals("")) {
			ehValido = false;
			throw new ValidacaoException("Campo CNH � Obrigat�rio!");
		}

		if (cnh.length() > 50) {
			ehValido = false;
			throw new ValidacaoException("Campo CNH Comporta no m�x. 50 chars!");
		}

		return ehValido;
	}

}
