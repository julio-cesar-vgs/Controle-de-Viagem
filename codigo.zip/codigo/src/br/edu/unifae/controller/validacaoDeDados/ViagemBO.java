package br.edu.unifae.controller.validacaoDeDados;

import br.edu.unifae.model.Caminhao;
import br.edu.unifae.model.Motorista;

public class ViagemBO {

	/**
	 * Procedimento para Validar a busca por nome e status, caso a busca for
	 * null, sera estourado uma excessao do Tipo Validacao Exception
	 * 
	 * @param buscaPorNomeEStatusDisponivel
	 * @throws ValidacaoException
	 */
	public static void validaMotoristaStatus(Motorista buscaPorNomeEStatusDisponivel) throws ValidacaoException {
		if (buscaPorNomeEStatusDisponivel == null)
			throw new ValidacaoException("Falha ao pesquisar o motorista");
	}

	/**
	 * Procedimento para validar o status do veiculo na viagem, caso a busca
	 * pela placa e status for igual a null, sera estourado uma excessao do Tipo
	 * Validacao Exception
	 * 
	 * @param buscarPorPlacaEStatus
	 * @throws ValidacaoException
	 */
	public static void validaCaminhaoStatus(Caminhao buscarPorPlacaEStatus) throws ValidacaoException {
		if (buscarPorPlacaEStatus == null)
			throw new ValidacaoException("Falha ao pesquisar Motorista");
	}
}