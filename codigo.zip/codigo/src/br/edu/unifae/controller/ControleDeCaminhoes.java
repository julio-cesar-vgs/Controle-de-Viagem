package br.edu.unifae.controller;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import br.edu.unifae.model.Caminhao;
import br.edu.unifae.modelo.enumerados.EnumCaminhao;

public class ControleDeCaminhoes {

	private  List<Caminhao> caminhoes = new ArrayList<>();
	private static int total = 1;

	/**
	 * Fun��o respons�vel por cadastar um novo caminh�o no sistema.
	 * 
	 * @param novo
	 * @return "true" em caso de sucesso ou "false" em caso de falha.
	 */
	public boolean cadastrarCaminhao(Caminhao novo) {
		novo.setId(total++);
		return caminhoes.add(novo);
	}

	/**
	 * 
	 * @param placa
	 * @return
	 */
	public Caminhao buscarPorPlaca(String placa) {
		for (Caminhao caminhao : caminhoes)
			if (caminhao.getPlaca().equalsIgnoreCase(placa))
				return caminhao;

		return null;
	}

	/**
	 * 
	 * @param status
	 * @return
	 */
	public List<Caminhao> buscarPorStatusTodosCaminhoes(EnumCaminhao status) {
		List<Caminhao> caminhoesComStatusPedido = new ArrayList<>();

		for (Caminhao caminhao : caminhoesComStatusPedido)
			if (caminhao.getStatus() == status)
				caminhoesComStatusPedido.add(caminhao);

		return caminhoesComStatusPedido;
	}

	/**
	 * 
	 * @param caminhao
	 * @return
	 */
/*	public boolean editCaminhao(Caminhao caminhao) {
		Caminhao caminhaoEditado = TesteMain.lerDadosDoCaminhao();
		caminhao.setPlaca(caminhaoEditado.getPlaca());
		caminhao.setRenavam(caminhaoEditado.getRenavam());
		caminhao.setOdometro(caminhaoEditado.getOdometro());
		return true;
	}*/

	/**
	 * 
	 * @return
	 */
	public List<Caminhao> buscarTodos() {
		return caminhoes;
	}

	/**
	 * 
	 * @param placaCaminhao
	 * @return
	 */
	public Caminhao buscarPorPlacaEStatus(String placaCaminhao) {
		for (Caminhao caminhao : caminhoes)
			if (caminhao.getPlaca().equalsIgnoreCase(placaCaminhao) &&
				caminhao.getStatus().equals(EnumCaminhao.Disponivel))
				return caminhao;

		return null;
	}
	
	/**
	 * 
	 * @param caminhaoASerModificadoStatus
	 * @param status
	 */
	public static void statusCaminhao(Caminhao caminhaoASerModificadoStatus, byte status) {
		switch (status) {
		case 1:
			caminhaoASerModificadoStatus.setStatus(EnumCaminhao.Disponivel);
			break;

		case 2:
			caminhaoASerModificadoStatus.setStatus(EnumCaminhao.Indisponivel);
			break;
		case 3:
			caminhaoASerModificadoStatus.setStatus(EnumCaminhao.Manutencao);
			
		default:
			JOptionPane.showMessageDialog(null, "Opcao Invalida, por padrao o valor ficara como disponivel");
			caminhaoASerModificadoStatus.setStatus(EnumCaminhao.Disponivel);
			break;
		}
	}
	
	public boolean existemCaminhoesCadastrados() {
		if (caminhoes.size() > 0)
			return true;
		else
			return false;
	}
}