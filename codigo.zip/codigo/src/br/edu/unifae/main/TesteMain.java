package br.edu.unifae.main;

public class TesteMain {
	/*private static DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

	static ControleDeManutencoes controleDeManutencoes = new ControleDeManutencoes();
	static MotoristaBO motoristaBO = new MotoristaBO();
	static CaminhaoBO caminhaoBO = new CaminhaoBO();

	
	// ### NÃO UTILIZAR A AUTO-IDENTAÇÃO NESTA CLASSE. ESTRAGARÁ A APARÊNCIA DOS MENUS.

	public static void main(String[] args) {
		byte opcaoDoUsuarioNoMenuPrincipal;

		do {
			opcaoDoUsuarioNoMenuPrincipal = menuPrincipal();
			switch (opcaoDoUsuarioNoMenuPrincipal) {
				case 1: menuCaminhao();	break;
				case 2: menuMotorista(); break;
				case 3:	menuViagem(); break;
				case 4:	msgFuncaoIncompleta(); break; // menuManutencao();
			case 0:
				JOptionPane.showMessageDialog(null, "OBRIGADO POR USAR O NOSSO SISTEMA", "Controle de Viagem",
						JOptionPane.INFORMATION_MESSAGE);
				break;

				default:msgOpcaoInvalida(); break;
			}
		} while (opcaoDoUsuarioNoMenuPrincipal != 0);
	}

	public static byte menuPrincipal() {
		return Byte.parseByte(JOptionPane.showInputDialog(null, "\n" + 
					".:: MENU PRINCIPAL ::.\n" + 
					"1. CAMINHÃO\n" + 
					"2. MOTORISTA\n" + 
					"3. VIAGEM\n" + 
					"4. MANUTENÇÃO\n" + 
					"0. SAIR",
				"Sistema de Controle Viagem", JOptionPane.INFORMATION_MESSAGE));
	}

	public static byte menuSecundario() {
		return Byte.parseByte(JOptionPane.showInputDialog(null, "\n" + 
						"1. NOVO \n" + 
						"2. EDITAR \n" + 
						"3. ALTERAR STATUS \n" + 
						"4. LISTAR TODOS \n" + 
						"5. PESQUISAR \n" + 
						"0. VOLTAR \n",
						"Escolha uma opção", JOptionPane.INFORMATION_MESSAGE));
	}

	public static byte menuDeViagem() {
		return Byte.parseByte(JOptionPane.showInputDialog(null, "" + 
						"1. NOVA VIAGEM \n" + 
						"2. FINALIZAR VIAGEM (Incompleta) \n" +
						"3. LISTAR TODAS AS VIAGENS \n" + 
						"4. LISTAR POR PERÍODO (Incompleta) \n" + 
						"0. VOLTAR \n",
						"Menu de Viagem", JOptionPane.INFORMATION_MESSAGE));
	}
	
	
	 * ===============================================
	 *  CAMINHÃO
	 * ===============================================
	 
	public static void menuCaminhao() {
		ControleDeCaminhoes controleDeCaminhoes = new ControleDeCaminhoes();
		ControleDeMotoristas controleDeMotoristas = new ControleDeMotoristas();
		byte opcaoDoUsuarioNoSubMenu;

		do {
			opcaoDoUsuarioNoSubMenu = menuSecundario();

			switch (opcaoDoUsuarioNoSubMenu) {
				case 1: // CADASTRAR
					Caminhao novoCaminhao = lerDadosDoCaminhao();
					if (controleDeCaminhoes.cadastrarCaminhao(novoCaminhao))
						msgCadastroComSucessoDeUm("Caminhao");
					else
						JOptionPane.showMessageDialog(null, "Não foi possível registrar o veículo");
					break;

				case 2: // EDITAR
					if (!controleDeCaminhoes.buscarTodos().isEmpty()) {
						String Placa = JOptionPane.showInputDialog(null, "PLACA DO CAMINHÃO: ");
						Caminhao caminhaoASerEditado = controleDeCaminhoes.buscarPorPlaca(Placa);
						
						if (caminhaoASerEditado != null)
							controleDeCaminhoes.editCaminhao(caminhaoASerEditado);
						else
							JOptionPane.showMessageDialog(null, "O caminhao com placa: " + Placa + " não foi encotrado: ");
					} 
					else
						msgNaoHaItensASeremExibidos();
					break;
	
				case 3:
					msgFuncaoIncompleta();
					break;
					
				case 4: // LISTAR
					JOptionPane.showMessageDialog(null, controleDeCaminhoes.buscarTodos());
					break;
					
				case 5: // EXCLUIR
					msgFuncaoIncompleta();
					break;
					
				default:
					msgOpcaoInvalida();
					break;
			}
		} while (opcaoDoUsuarioNoSubMenu != 0);
	}

	public static Caminhao lerDadosDoCaminhao() {
		try {
			String placaCaminhao = JOptionPane.showInputDialog("PLACA: ");
			String chassi = JOptionPane.showInputDialog("CHASSI: ");
			String renavam = JOptionPane.showInputDialog("RENAVAM (11 Digitos): ");			
			int odometro = Integer.parseInt(JOptionPane.showInputDialog("ODÔMETRO: "));

			caminhaoBO.validarPlaca(placaCaminhao);
			caminhaoBO.validarRenavam(renavam);
			caminhaoBO.validaOdometro(odometro);
			return new Caminhao(placaCaminhao, chassi, renavam, odometro);
			
		} catch (Exception e) {
			msgOcorreuErro(e);
		}
		return null;
	}

	
	 * ===============================================
	 *  MOTORISTA
	 * ===============================================
	 
	public static void menuMotorista() {
		byte opcaoDoUsuarioNoSubMenu;
		ControleDeMotoristas controleDeMotoristas = new ControleDeMotoristas();

		do {
			opcaoDoUsuarioNoSubMenu = menuSecundario();

			switch (opcaoDoUsuarioNoSubMenu) {
			case 1: // CADASTRAR
				  Motorista novoMotorista = lerDadosDosMotoristas(); 
				  if (controleDeMotoristas.cadastrarMotorista(novoMotorista))
					  msgCadastroComSucessoDeUm("Motorista");
				
				  break;
	
			case 2: // EDITAR
				if (!controleDeMotoristas.listarTodosMotoristas().isEmpty()) {
					String nome = JOptionPane.showInputDialog(null, "NOME DO MOTORISTA: ");
					Motorista motoristaASerEditado = controleDeMotoristas.buscarPorNome(nome);
					if(motoristaASerEditado!=null){
						controleDeMotoristas.editarMotorista(motoristaASerEditado);	
						JOptionPane.showMessageDialog(null, "Motorista Editado com Sucesso","Sistema Controle de Viagem",JOptionPane.INFORMATION_MESSAGE);
					}else
						JOptionPane.showMessageDialog(null, "Motorista: " + nome + ", não Encontrado!","Sistema Controle de Viagem",JOptionPane.INFORMATION_MESSAGE);
					
				} 
				else
					msgNaoHaItensASeremExibidos();
				break;
	
			case 3: // ALTERAR STATUS DO MOTORISTA
				if (!controleDeMotoristas.listarTodosMotoristas().isEmpty()) {
					String nome = JOptionPane.showInputDialog(null, "NOME DO MOTORISTA: ");
					Motorista motoristaASerEditado = controleDeMotoristas.buscaPorNomeEStatusDisponivel(nome);
					
					if (motoristaASerEditado != null) {
						byte status = menuStatusDoMotorista();
						ControleDeMotoristas.statusMotorista(motoristaASerEditado, status);
						JOptionPane.showMessageDialog(null, "Status alterado com sucesso.");
					} 
					else 
						JOptionPane.showMessageDialog(null, "Motorista não encontrado");
				} 
				else
					msgNaoHaItensASeremExibidos();
				break;

				
			case 4: // EXIBIR
				if (!controleDeMotoristas.listarTodosMotoristas().isEmpty())
					JOptionPane.showMessageDialog(null, controleDeMotoristas.listarTodosOrdenadosPorNome());
				else
					msgNaoHaItensASeremExibidos();
				break;
			
			
			case 5: // PESQUISAR
				if (!controleDeMotoristas.listarTodosMotoristas().isEmpty()) {
					byte metodoBusca = menuDePesquisarMotoristas();
					
					if (metodoBusca == 1)
						buscaPorMotorista(controleDeMotoristas);
					else if (metodoBusca == 2)
						buscaPorStatus(controleDeMotoristas);
					else if (metodoBusca==3)
						buscaPorCPF(controleDeMotoristas);
					else
						msgOpcaoInvalida();
				}		
				else
					msgNaoHaItensASeremExibidos();
				break;
				
			default:
				msgOpcaoInvalida();
				break;
			}
		} while (opcaoDoUsuarioNoSubMenu != 0);
	}

	private static void buscaPorCPF(ControleDeMotoristas controleDeMotoristas) {
		String cpf = JOptionPane.showInputDialog(null,"CPF");
		Motorista buscarNomePorCPF = controleDeMotoristas.buscarNomePorCPF(cpf);
		if (buscarNomePorCPF != null)
			JOptionPane.showMessageDialog(null, "Dados do motorista: " + buscarNomePorCPF);
		else
			JOptionPane.showMessageDialog(null, "CPF: " + cpf + " não foi encotrado");
	}

	public static byte menuDePesquisarMotoristas() {
		return Byte.parseByte(JOptionPane.showInputDialog(null, "" + 
				"Método de Busca: \n" +
				"1. Buscar Motorista Nome\n" + 
				"2. Busca por status\n" + 
				"3. Busca por CPF","Menu Pesquisa Motorista",JOptionPane.PLAIN_MESSAGE));
	}
	
	public static byte menuStatusDoMotorista() {
		return Byte.parseByte(JOptionPane.showInputDialog(null,
				"1. Aposentado \n" + 
				"2. Disponivel\n" + 
				"3. Férias \n" +
				"4. Indisponivel","Status do Motorista",JOptionPane.PLAIN_MESSAGE));
	}
	
	
	*//**
	 * Realiza a busca de motorista pelo campo nome.
	 * 
	 * @param controlarMotorista
	 *//*
	private static void buscaPorMotorista(ControleDeMotoristas controlarMotorista) {
		String nome = JOptionPane.showInputDialog(null, "NOME DO MOTORISTA: ");
		Motorista buscarPorNome = controlarMotorista.buscarPorNome(nome);
		
		if (buscarPorNome != null)
			JOptionPane.showMessageDialog(null, "Dados do motorista: " + buscarPorNome);
		else
			JOptionPane.showMessageDialog(null, "Motorista: " + nome + " não foi encotrado");
	}

	*//**
	 * Listar todos os motoristas dado o status de busca.
	 * @param controlarMotorista
	 *//*
	private static void buscaPorStatus(ControleDeMotoristas controlarMotorista) {
		byte status = menuStatusDoMotorista();

		if (status == 1)
			JOptionPane.showMessageDialog(null, controlarMotorista.buscaPorStatus(EnumMotorista.Disponivel));
		else if (status == 2)
			JOptionPane.showMessageDialog(null, controlarMotorista.buscaPorStatus(EnumMotorista.Aposentado));
		else if (status == 3)
			JOptionPane.showMessageDialog(null, controlarMotorista.buscaPorStatus(EnumMotorista.Ferias));
		else if (status == 4)
			JOptionPane.showMessageDialog(null, controlarMotorista.buscaPorStatus(EnumMotorista.Indisponivel));
	}
	
	

	public static Motorista lerDadosDosMotoristas() {
		 Leitura e validação dos dados do motorista 
		try {
			String nome = JOptionPane.showInputDialog(null, "Nome: ", "Cadastro de Motoristas",JOptionPane.QUESTION_MESSAGE);			
			String cpf = JOptionPane.showInputDialog(null,"CPF (11 digitos e sem pontos): ", "Cadastro de Motoristas",JOptionPane.QUESTION_MESSAGE);
			String cnh = JOptionPane.showInputDialog(null, "Cateira de Habilitação", "Cadastro de Motoristas",JOptionPane.QUESTION_MESSAGE);

			motoristaBO.validarNome(nome);
			motoristaBO.validarCPF(cpf);
			motoristaBO.validarCNH(cnh);
			
			Motorista motorista = new Motorista(nome, cpf, cnh);
			return motorista;

		} catch (Exception e) {
			msgOcorreuErro(e);
		}
		
		return null;
	}
	
	

	
	 * ===============================================
	 *  VIAGEM
	 * ===============================================
	 
	public static void menuViagem() {
		byte opcaoDoUsuarioNoSubMenu;
		ControleDeViagens controleDeViagem = new ControleDeViagens();

		do {
			opcaoDoUsuarioNoSubMenu = menuDeViagem();

			switch (opcaoDoUsuarioNoSubMenu) {
				case 1: // CADASTRAR
					Viagem novaViagem = lerDadosViagem();
					
					if (controleDeViagem.cadastrarViagem(novaViagem))
						JOptionPane.showMessageDialog(null, "Viagem cadastrada com sucesso");

					break;
	
				case 2: // FINALIZAR
					msgFuncaoIncompleta();
					break;
	
				case 3: // LISTAR
					if (controleDeViagem.existemViagensCadastrados())
						JOptionPane.showMessageDialog(null, controleDeViagem.listarTodasOrdenadaPorPlaca());
					else
						msgNaoHaItensASeremExibidos();
					break;
	
				case 4: // LISTAR DENTRO DE UM PERÍODO
					msgFuncaoIncompleta();
					break;

				default:
					msgOpcaoInvalida();
					break;
			}
		} while (opcaoDoUsuarioNoSubMenu != 0);
	}

	public static Viagem lerDadosViagem() {
		ControleDeMotoristas controleDeMotoristas = new ControleDeMotoristas();
		ControleDeCaminhoes controleDeCaminhoes = new ControleDeCaminhoes();

		try {
			String dataIncio = JOptionPane.showInputDialog(null, "DATA DA VIAGEM [dd/mm/aaaa]: )", "Cadastro de Viagem", 3);
			String placaDoCaminhao = JOptionPane.showInputDialog(null, "PLACA DO CAMINHÃO: ", "Cadastro de Viagem", 3);
			String motorista = JOptionPane.showInputDialog(null, "NOME DO MOTORISTA: ", "Cadastro de Viagem", 3);
			
			double diariaDoMotorista = 
					Double.parseDouble(JOptionPane.showInputDialog(null, "DIÁRIA DO MOTORISTA: ", "Cadastro de Viagem", 3));

			// VALIDAÇÕES NECESSÁRIAS
			motoristaBO.validarNome(motorista);
			Date dataInicioConvertida = dateFormat.parse(dataIncio);

			caminhaoBO.validarPlaca(placaDoCaminhao);

			// TODOS OS DADOS, ESTÃO COERENTES COM A VIAGEM?
			Caminhao buscaPorPlacaEStatus = controleDeCaminhoes.buscarPorPlacaEStatus(placaDoCaminhao);
			ViagemBO.validaCaminhaoStatus(buscaPorPlacaEStatus);
			Motorista buscaPorNomeEStatusDisponivel = controleDeMotoristas.buscaPorNomeEStatusDisponivel(motorista);
			ViagemBO.validaMotoristaStatus(buscaPorNomeEStatusDisponivel);

			// ALTERAÇÃO "AUTOMATICA" DO STATUS
			ControleDeMotoristas.statusMotorista(buscaPorNomeEStatusDisponivel, (byte) 4);
			ControleDeCaminhoes.statusCaminhao(buscaPorPlacaEStatus, (byte) 2);
			Viagem viagem = new Viagem(dataInicioConvertida, buscaPorPlacaEStatus, buscaPorNomeEStatusDisponivel,
					diariaDoMotorista);
			return viagem;
			
		} catch (Exception e) {
			msgOcorreuErro(e);
		}
		
		return null;
	}

	private static void msgNaoHaItensASeremExibidos() {
		JOptionPane.showMessageDialog(null, "Nao há dados a serem exibidos", "Sistema Controle de Viagem",
				JOptionPane.ERROR_MESSAGE);
	}

	private static void msgFuncaoIncompleta() {
		JOptionPane.showMessageDialog(null, "Implementação ainda não concluída.", "Em Desenvolvimento!",
				JOptionPane.ERROR_MESSAGE);
	}
	
	private static void msgOpcaoInvalida() {
		JOptionPane.showMessageDialog(null, "Opção Inválida. Por favor, informe uma opção válida.", "Controle de Viagem",
				JOptionPane.ERROR_MESSAGE);
	}
	
	private static void msgOcorreuErro(Exception e) {
		JOptionPane.showMessageDialog(null, "Ocorreu um erro. Verifique o suporte técnico. Erro: " + e.getMessage(), "Controle de Viagem",
				JOptionPane.ERROR_MESSAGE);
	}
	
	private static void msgCadastroComSucessoDeUm(String s) {
		JOptionPane.showMessageDialog(null, s + " cadastrado com sucesso.", "Controle de Viagem", JOptionPane.INFORMATION_MESSAGE);
	}*/
}