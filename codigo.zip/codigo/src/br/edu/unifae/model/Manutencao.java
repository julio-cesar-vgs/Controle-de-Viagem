package br.edu.unifae.model;

import java.util.Date;

import br.edu.unifae.modelo.enumerados.EnumCaminhao;

public class Manutencao {

	private Date dataEntrada;
	private Date dataSaida;
	private String servico;
	private Caminhao caminhao;

	public Manutencao(Caminhao caminhao, Date dataEntrada) {
		this.dataEntrada = dataEntrada;
		this.caminhao = caminhao;
	}

	public Manutencao() {

	}

	public void finalizaManutencao(Date dataSaida, String placa, String servico) {
		this.dataSaida = dataSaida;
		this.servico = servico;
	}
	
	public void setDataEntrada(Date dataEntrada) {
		this.dataEntrada = dataEntrada;
	}

	public void setDataSaida(Date dataSaida) {
		this.dataSaida = dataSaida;
	}

	public void setServico(String servico) {
		this.servico = servico;
	}

	public Date getDataEntrada() {
		return dataEntrada;
	}

	public Date getDataSaida() {
		return dataSaida;
	}

	public String getServico() {
		return servico;
	}

	public Caminhao getCaminhao() {
		return caminhao;
	}

	@Override
	public String toString() {
		return "Manutencao [dataEntrada=" + dataEntrada + ", dataSaida=" + dataSaida + ", servico=" + servico
				+ ", caminhao=" + caminhao + "]";
	}
}
