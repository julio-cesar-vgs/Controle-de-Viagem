package br.edu.unifae.model;

import br.edu.unifae.modelo.enumerados.EnumCarga;

public class Carga {

	private String tipo;
	private double quantidade;
	private EnumCarga unidade;

	public Carga(String tipo, double quantidade) {
		this.tipo = tipo;
		this.quantidade = quantidade;
	}

	public double getQuantidade() {
		return quantidade;
	}

	public String getTipo() {
		return tipo;
	}

	public EnumCarga getUnidade() {
		return unidade;
	}

	public void setQuantidade(double quantidade) {
		this.quantidade = quantidade;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public void setUnidade(EnumCarga unidade) {
		this.unidade = unidade;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TIPO: ").append(tipo)
			   .append(" QUANTIDADE: ").append(quantidade)
			   .append(" UNIDADE: ").append(unidade);
		return builder.toString();
	}
}
