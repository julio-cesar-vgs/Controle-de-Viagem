package br.edu.unifae.model;

import java.util.Date;

public class Pedagio {

	private Date data;
	private String praca;
	private double valor;

	public Pedagio(double valor) {
		this.valor = valor;
	}

	public Date getData() {
		return data;
	}

	public String getPraca() {
		return praca;
	}

	public double getValor() {
		return valor;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public void setPraca(String praca) {
		this.praca = praca;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
	
	public String toSting() {
		StringBuilder builder = new StringBuilder();
		builder.append(" DATA: ").append(data)
			   .append(" PRA�A: ").append(praca)
			   .append(" VALOR: ").append(valor);
		return builder.toString();
	}
}
