package br.edu.unifae.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import br.edu.unifae.modelo.enumerados.EnumMotorista;

public class Motorista {

	private Integer id;
	private String celular;
	private String cnh;
	private String cpf;
	private Date dataDeNascimento;
	private String nome;
	private String orgaoExpedidor;
	private String rg;
	private char sexo;
	private EnumMotorista status;
	private String telefone;
	SimpleDateFormat dataFormatada = new SimpleDateFormat("dd/MM/yyyy");


	public Motorista(String nome, String cpf, String cnh) {
		this.nome = nome;
		this.cpf = cpf;
		this.cnh = cnh;
		status = EnumMotorista.Disponivel;
	}
	
	

	public Motorista(Integer id, String celular, String cnh, String cpf, Date dataDeNascimento, String nome,
			String orgaoExpedidor, String rg, char sexo, EnumMotorista status, String telefone) {
		super();
		this.id = id;
		this.celular = celular;
		this.cnh = cnh;
		this.cpf = cpf;
		this.dataDeNascimento = dataDeNascimento;
		this.nome = nome;
		this.orgaoExpedidor = orgaoExpedidor;
		this.rg = rg;
		this.sexo = sexo;
		this.status = status;
		this.telefone = telefone;
		
	}



	public Motorista() {
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCelular() {
		return celular;
	}

	public String getCnh() {
		return cnh;
	}

	public String getCpf() {
		return cpf;
	}

	public Date getDataDeNascimento() {
		return dataDeNascimento;
	}

	public String getNome() {
		return nome;
	}

	public String getOrgaoExpedidor() {
		return orgaoExpedidor;
	}

	public String getRg() {
		return rg;
	}

	public char getSexo() {
		return sexo;
	}

	public EnumMotorista getStatus() {
		return status;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}

	public void setCnh(String cnh) {
		this.cnh = cnh;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public void setDataDeNascimento(Date dataDeNascimento) {
		this.dataDeNascimento = dataDeNascimento;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setOrgaoExpedidor(String orgaoExpedidor) {
		this.orgaoExpedidor = orgaoExpedidor;
	}

	public void setRg(String rg) {
		this.rg = rg;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public void setStatus(EnumMotorista status) {
		this.status = status;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(" NOME: ").append(nome)
		.append(" CPF: ").append(cpf)
		.append(" CNH: ").append(cnh)
		.append(" STATUS: ").append(getStatus())
		.append(" Data Nascimento").append(dataFormatada.format(getDataDeNascimento().getTime()))
		.append("\n");
		return builder.toString();
	}
	
}
