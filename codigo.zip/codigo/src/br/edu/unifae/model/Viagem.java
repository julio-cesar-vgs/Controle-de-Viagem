package br.edu.unifae.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.edu.unifae.modelo.enumerados.EnumViagem;

public class Viagem {
	private Integer idViagem;
	private List<Abastecimento> abastecimentos;
	private Motorista condutor;
	private Caminhao caminhao;
	private String Carroceria;
	private Date dataFim;
	private Date dataInicio;
	private double diariaDoMotorista;
	private GastoExtra gastosExtras;
	private int odometroFinal;
	private int odometroInicial;
	private List<Pedagio> pedagios;
	private EnumViagem status;
	private double totalDespesas;
	private double totalGastoExtra;
	private double totalOleoLitros;
	private double totalOleoReais;
	private double totalPedagio;
	private int totalQuilometrosPercorridos;
	List<GastoExtra> gastoExtras = new ArrayList<>();

	// Este construtor quem que ser verificado;
	// Pois ha o motorista passando por parametro mas nao ha atributo dele na
	// classe
	public Viagem(Date dataInicio, Caminhao caminhao, Motorista condutor, double diariaDoMotorista) {
		this.dataInicio = dataInicio;
		this.caminhao = caminhao;
		this.condutor = condutor;
		this.diariaDoMotorista = diariaDoMotorista;
	}

	private void calcTotalGastoExtra() {
		double soma = gastoExtras.stream().mapToDouble(GastoExtra::getValor).sum();
	}

	private void calcTotalOleoLitrosEReais() {
		double total = gastoExtras.stream().mapToDouble(GastoExtra::getValor).sum();
	}

	private void calcTotalPedagio() {
		double total = pedagios.stream().mapToDouble(Pedagio::getValor).sum();
	}

	public void finalizaViagem(Date dataFim, int odometroFinal, List<Pedagio> pedagios,
			List<Abastecimento> abastecimentos, List<GastoExtra> gastosExtras) {
		this.dataFim = dataFim;
		this.odometroFinal = odometroFinal;
		this.pedagios = pedagios;
		this.abastecimentos = abastecimentos;
		this.status = EnumViagem.Finalizada;
		this.odometroFinal = this.caminhao.getOdometro();
		calcTotalGastoExtra();
		calcTotalOleoLitrosEReais();
		calcTotalPedagio();
		this.totalQuilometrosPercorridos = odometroFinal - this.odometroInicial;
	}

	public List<Abastecimento> getAbastecimentos() {
		return abastecimentos;
	}

	public Motorista getCondutor() {
		return condutor;
	}

	public void setCondutor(Motorista condutor) {
		this.condutor = condutor;
	}

	public Caminhao getCaminhao() {
		return caminhao;
	}

	public String getCarroceria() {
		return Carroceria;
	}

	public Date getDataFim() {
		return dataFim;
	}

	public Date getDataInicio() {
		return dataInicio;
	}

	public double getDiariaDoMotorista() {
		return diariaDoMotorista;
	}

	public GastoExtra getGastosExtras() {
		return gastosExtras;
	}

	public int getOdometroFinal() {
		return odometroFinal;
	}

	public int getOdometroInicial() {
		return odometroInicial;
	}

	public List<Pedagio> getPedagios() {
		return pedagios;
	}

	public EnumViagem getStatus() {
		return status;
	}
	
	public void setStatus(EnumViagem status) {
		this.status = status;
	}

	public double getTotalDespesas() {
		return totalDespesas;
	}

	public double getTotalGastoExtra() {
		return totalGastoExtra;
	}

	public double getTotalOleoLitros() {
		return totalOleoLitros;
	}

	public double getTotalOleoReais() {
		return totalOleoReais;
	}

	public double getTotalPedagio() {
		return totalPedagio;
	}

	public int getTotalQuilometrosPercorridos() {
		return totalQuilometrosPercorridos;
	}

	public void setCarroceria(String carroceria) {
		Carroceria = carroceria;
	}

	public void setAbastecimentos(List<Abastecimento> abastecimentos) {
		this.abastecimentos = abastecimentos;
	}

	public void setGastoExtras(List<GastoExtra> gastoExtras) {
		this.gastoExtras = gastoExtras;
	}

	public void setTotalGastoExtra(double totalGastoExtra) {
		this.totalGastoExtra = totalGastoExtra;
	}

	@Override
	public String toString() {
		StringBuilder builder =  new StringBuilder();
		builder.append("id: ").append(idViagem).append(", condutor: ").append(condutor).append(", caminhao: ")
				.append(caminhao).append(", dataInicio: ").append(dataInicio).append(", diariaDoMotorista: ")
				.append(diariaDoMotorista).append(", status: ").append(status).append("]");
		return builder.toString();
	}

	public void setIdViagem(Integer idViagem) {
		this.idViagem = idViagem;
	}

	public Integer getIdViagem() {
		return idViagem;
	}


	
}