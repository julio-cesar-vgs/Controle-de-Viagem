package br.edu.unifae.model;

import br.edu.unifae.modelo.enumerados.EnumCaminhao;

public class Caminhao {

	private int id;
	private int anoFabricacao;
	private int anoModelo;
	private String chassi;
	private double consumoMedioLKm;
	private String modelo;
	private int odometro;
	private String placa;
	private String renavam;
	private EnumCaminhao status;

	public Caminhao(String placa, String chassi, String renavam, int odometro) {
		this.placa = placa;
		this.chassi = chassi;
		this.renavam = renavam;
		this.odometro = odometro;
		this.status = EnumCaminhao.Disponivel;
	}

	public int getAnoFabricacao() {
		return anoFabricacao;
	}
	
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	
	public void setChassi(String chassi) {
		this.chassi = chassi;
	}

	public void setRenavam(String renavam) {
		this.renavam = renavam;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAnoModelo() {
		return anoModelo;
	}

	public String getChassi() {
		return chassi;
	}

	public double getConsumoMedioLKm() {
		return consumoMedioLKm;
	}

	public String getModelo() {
		return modelo;
	}

	public int getOdometro() {
		return odometro;
	}

	public String getPlaca() {
		return placa;
	}

	public String getRenavam() {
		return renavam;
	}

	public EnumCaminhao getStatus() {
		return status;
	}

	public void setAnoFabricacao(int anoFabricacao) {
		this.anoFabricacao = anoFabricacao;
	}

	public void setAnoModelo(int anoModelo) {
		this.anoModelo = anoModelo;
	}

	public void setConsumoMedioLKm(double consumoMedioLKm) {
		this.consumoMedioLKm = consumoMedioLKm;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public void setOdometro(int odometro) {
		this.odometro = odometro;
	}

	public void setStatus(EnumCaminhao status) {
		this.status = status;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(" CHASSI: ").append(chassi).append(" OD�METRO: ").append(odometro).append(" PLACA: ")
				.append(placa).append(" RENAVAM: ").append(renavam);
		return builder.toString();
	}
}
