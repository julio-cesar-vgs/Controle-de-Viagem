package br.edu.unifae.model;

import java.util.Date;

public class GastoExtra {

	private String razaoSocial;
	private String notaFiscal;
	private double valor;
	private String descricao;
	private Date data;

	public GastoExtra(double valor, String descricao) {
		this.valor = valor;
		this.descricao = descricao;
	}

	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	public void setNotaFiscal(String notaFiscal) {
		this.notaFiscal = notaFiscal;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getRazaoSocial() {
		return razaoSocial;
	}

	public String getNotaFiscal() {
		return notaFiscal;
	}

	public double getValor() {
		return valor;
	}

	public String getDescricao() {
		return descricao;
	}

	public Date getData() {
		return data;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(" RAZ�O SOCIAL: ").append(razaoSocial)
			   .append(" NOTA FISCAL: ").append(notaFiscal)
			   .append(" VALOR: ").append(valor)
			   .append(" DESCRI��O: ").append(descricao)
			   .append(" DATA: ").append(data);
		return builder.toString();
	}
}
