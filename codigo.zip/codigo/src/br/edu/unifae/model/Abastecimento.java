package br.edu.unifae.model;

import java.util.Date;

public class Abastecimento {

	private Date dataAbastecimento;
	private String posto;
	private double totalOleoLitros;
	private double totalOleoReais;

	public Abastecimento(Date dataAbastecimento, double totalOleoLitros, double totalOleoReais) {
		this.totalOleoReais = totalOleoReais;
		this.dataAbastecimento = dataAbastecimento;
		this.totalOleoLitros = totalOleoLitros;
	}

	public Date getDataAbastecimento() {
		return dataAbastecimento;
	}

	public String getPosto() {
		return posto;
	}

	public double getTotalOleoLitros() {
		return totalOleoLitros;
	}

	public double getTotalOleoReais() {
		return totalOleoReais;
	}

	public void setDataAbastecimento(Date dataAbastecimento) {
		this.dataAbastecimento = dataAbastecimento;
	}

	public void setPosto(String posto) {
		this.posto = posto;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(" DATA DO ABASTECIMENTO: ").append(dataAbastecimento).append("POSTO:").append(posto)
				.append(" TOTAL DE LITROS: ").append(totalOleoLitros).append(" TOTAL DE REAIS: ")
				.append(totalOleoReais);
		return builder.toString();
	}
}