package br.edu.unifae.modelo.enumerados;

public enum EnumMotorista {
	Aposentado, Disponivel, Ferias, Indisponivel;
}
