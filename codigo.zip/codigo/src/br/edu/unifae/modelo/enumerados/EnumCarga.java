package br.edu.unifae.modelo.enumerados;
public enum EnumCarga {
	Graneleiro, Tanque, CargaSeca;
}
