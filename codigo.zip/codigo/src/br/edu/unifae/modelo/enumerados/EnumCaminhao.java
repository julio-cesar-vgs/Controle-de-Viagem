package br.edu.unifae.modelo.enumerados;
public enum EnumCaminhao {
	Disponivel, Indisponivel, Manutencao;
}
