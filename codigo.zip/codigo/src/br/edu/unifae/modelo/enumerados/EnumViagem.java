package br.edu.unifae.modelo.enumerados;
public enum EnumViagem {
	Aberta, Finalizada
}
